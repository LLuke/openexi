package com.thaiopensource.exi.xsd.regex.jdk1_4;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 */
public class RegexiTest extends TestCase {

  public RegexiTest(String name) {
    super(name);
  }

  public static Test suite() {
    return new TestSuite(RegexiTest.class);
  }

  ///////////////////////////////////////////////////////////////////////////
  // Test cases
  ///////////////////////////////////////////////////////////////////////////

  /**
   * Compiling an invalid pattern results in an exception.
   */
  public void testInvalidPattern_01() throws Exception {
    
    try {
      Regexi.compute("[A-}*");
    }
    catch (Exception sve) {
      Assert.assertEquals("expected \"]\"", sve.getMessage());
      return;
    }
    Assert.fail("The operation should have resulted in an exception.");
  }

  /**
   * Nested subtraction of character classes
   */
  public void testNestedSubtraction_01() throws Exception {
    
    int[] chars = Regexi.compute("[A-Z-[C-X-[M-N]]]*");
    
    Assert.assertEquals(6, chars.length);
    
    // AB MN YZ
    Assert.assertEquals((int)'A', chars[0]);
    Assert.assertEquals((int)'B', chars[1]);
    Assert.assertEquals((int)'M', chars[2]);
    Assert.assertEquals((int)'N', chars[3]);
    Assert.assertEquals((int)'Y', chars[4]);
    Assert.assertEquals((int)'Z', chars[5]);
  }

  /**
   */
  public void testUnion_01() throws Exception {
    
    int[] chars = Regexi.compute("[a-cg-i]");
    
    Assert.assertEquals(6, chars.length);
    
    // abc ghi
    Assert.assertEquals((int)'a', chars[0]);
    Assert.assertEquals((int)'b', chars[1]);
    Assert.assertEquals((int)'c', chars[2]);
    Assert.assertEquals((int)'g', chars[3]);
    Assert.assertEquals((int)'h', chars[4]);
    Assert.assertEquals((int)'i', chars[5]);
  }

  /**
   */
  public void testUnion_02() throws Exception {
    
    int[] chars = Regexi.compute("[g-ia-c]");
    
    Assert.assertEquals(6, chars.length);
    
    // abc ghi
    Assert.assertEquals((int)'a', chars[0]);
    Assert.assertEquals((int)'b', chars[1]);
    Assert.assertEquals((int)'c', chars[2]);
    Assert.assertEquals((int)'g', chars[3]);
    Assert.assertEquals((int)'h', chars[4]);
    Assert.assertEquals((int)'i', chars[5]);
  }

  /**
   */
  public void testUnion_03() throws Exception {
    
    int[] chars = Regexi.compute("[acbdcbfe]");
    
    Assert.assertEquals(6, chars.length);
    
    // abc ghi
    Assert.assertEquals((int)'a', chars[0]);
    Assert.assertEquals((int)'b', chars[1]);
    Assert.assertEquals((int)'c', chars[2]);
    Assert.assertEquals((int)'d', chars[3]);
    Assert.assertEquals((int)'e', chars[4]);
    Assert.assertEquals((int)'f', chars[5]);
  }

  /**
   */
  public void testComplement_01() throws Exception {
    
    int[] chars = Regexi.compute("[^zyxwvuts-[^abcihgst]]");
    
    Assert.assertEquals(6, chars.length);
    
    // abc ghi
    Assert.assertEquals((int)'a', chars[0]);
    Assert.assertEquals((int)'b', chars[1]);
    Assert.assertEquals((int)'c', chars[2]);
    Assert.assertEquals((int)'g', chars[3]);
    Assert.assertEquals((int)'h', chars[4]);
    Assert.assertEquals((int)'i', chars[5]);
  }

  /**
   */
  public void testRegexp_01() throws Exception {
    
    int[] chars = Regexi.compute("([a-zA-Z]{1,8})(-[a-zA-Z0-9]{1,8})*");
    
    Assert.assertEquals(63, chars.length);
    
    Assert.assertEquals(((int)'-'), chars[0]);
    
    int i;
    for (i = 0; i < 10; i++) {
      Assert.assertEquals(((int)'0') + i, chars[1 + i]);
    }
    for (i = 0; i < 26; i++) {
      Assert.assertEquals(((int)'A') + i, chars[11 + i]);
    }
    for (i = 0; i < 26; i++) {
      Assert.assertEquals(((int)'a') + i, chars[37 + i]);
    }
  }

  /**
   */
  public void testRegexp_02() throws Exception {
    
    int[] chars = Regexi.compute("[A-Z]{1}[a-n,q-z,A-N,Q-Z]{2}[0-9]{4}|NOTSET");
    
    Assert.assertEquals(61, chars.length);
    
    Assert.assertEquals(',', (char)chars[0]);
    
    int i;
    for (i = 0; i < 10; i++) {
      Assert.assertEquals(((char)((int)'0') + i), (char)chars[1 + i]);
    }
    for (i = 0; i < 26; i++) {
      Assert.assertEquals(((int)'A') + i, chars[11 + i]);
    }
    for (i = 0; i < 14; i++) {
      Assert.assertEquals(((char)((int)'a') + i), (char)chars[37 + i]);
    }
    for (i = 0; i < 10; i++) {
      Assert.assertEquals(((char)((int)'q') + i), (char)chars[51 + i]);
    }
  }
  
  /**
   * Test an empty beanch at the beginning.
   */
  public void testEmptyBranch_01() throws Exception {
    
    int[] chars = Regexi.compute("|[0-2]{2}");
    
    Assert.assertEquals(3, chars.length);
    
    Assert.assertEquals((int)'0', chars[0]);
    Assert.assertEquals((int)'1', chars[1]);
    Assert.assertEquals((int)'2', chars[2]);
  }

  /**
   * Test an empty beanch at the end.
   */
  public void testEmptyBranch_02() throws Exception {
    
    int[] chars = Regexi.compute("[0-2]{2}|");
    
    Assert.assertEquals(3, chars.length);
    
    Assert.assertEquals((int)'0', chars[0]);
    Assert.assertEquals((int)'1', chars[1]);
    Assert.assertEquals((int)'2', chars[2]);
  }

  /**
   * Test an empty beanch in the middle.
   */
  public void testEmptyBranch_03() throws Exception {
    
    int[] chars = Regexi.compute("[5-7]{2}||[0-2]{2}");
    
    Assert.assertEquals(6, chars.length);
    
    // 0, 1, 2, 5, 6, 7
    Assert.assertEquals((int)'0', chars[0]);
    Assert.assertEquals((int)'1', chars[1]);
    Assert.assertEquals((int)'2', chars[2]);
    Assert.assertEquals((int)'5', chars[3]);
    Assert.assertEquals((int)'6', chars[4]);
    Assert.assertEquals((int)'7', chars[5]);
  }

}