package com.thaiopensource.exi.xsd.regex.jdk1_4;

import junit.framework.Test;
import junit.framework.TestSuite;

public class testpkg extends TestSuite {
  
  public testpkg(String name) {
    super(name);
  }

  public static Test suite() {
    TestSuite suite = new TestSuite();

    suite.addTest(RegexiTest.suite());
    
    return suite;
  }

  public static void main(String args[]) {
    junit.textui.TestRunner.run(suite());
  }

}
