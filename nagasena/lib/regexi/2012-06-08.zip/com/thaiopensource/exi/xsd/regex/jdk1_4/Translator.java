package com.thaiopensource.exi.xsd.regex.jdk1_4;

import com.thaiopensource.exi.util.Utf16;
import com.thaiopensource.exi.xsd.regex.RegexSyntaxException;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;
import java.math.BigDecimal;

/**
 * Translates XML Schema regexes into EXI restricted character set.
 *
 * @see <a href="http://www.w3.org/TR/xmlschema-2/#regexs">XML Schema Part 2</a>
 * @see <a href="http://www.w3.org/TR/exi/#regexToCharset">Deriving Character Sets from XML Schema Regular Expressions</a> 
 */
class Translator {
  private final String regExp;
  private int pos = 0;
  private final int length;
  private char curChar;
  private boolean eos = false;
  
  //private static final int NONBMP_MIN = 0x10000;
  private static final int NONBMP_MAX = 0x10FFFF;
  
  //static private final ArrayList<SimpleCharClass> CHARS_NONE;
  //static private final ArrayList<SimpleCharClass> CHARS_ALL; 
  
  static {
    //CHARS_NONE = new ArrayList<SimpleCharClass>();
    //CHARS_ALL = new ArrayList<SimpleCharClass>();
    //CHARS_ALL.add(new CharRange(0, NONBMP_MAX));
  }

  static protected final char EOS = '\0';

  protected Translator(String regExp) {
    this.regExp = regExp;
    this.length = regExp.length();
  }
  
  /**
   * Translates a regular expression in the syntax of XML Schemas Part 2 into a regular
   * expression in the syntax of <code>java.util.regex.Pattern</code>.  The translation
   * assumes that the string to be matched against the regex uses surrogate pairs correctly.
   * If the string comes from XML content, a conforming XML parser will automatically
   * check this; if the string comes from elsewhere, it may be necessary to check
   * surrogate usage before matching.
   *
   * @param regexp a String containing a regular expression in the syntax of XML Schemas Part 2
   * @return TranslationInfo containing a String representing a regular expression in the syntax of java.util.regex.Pattern
   * @throws RegexSyntaxException if <code>regexp</code> is not a regular expression in the
   * syntax of XML Schemas Part 2
   * @see java.util.regex.Pattern
   * @see <a href="http://www.w3.org/TR/xmlschema-2/#regexs">XML Schema Part 2</a>
   */
  public static List<SimpleCharClass> translate(String regexp)
    throws RegexSyntaxException {
    Translator tr = new Translator(regexp);
    return _translate(tr);
  }
  
  /**
   * Translates a regular expression in the syntax of XML Schemas Part 2 into a regular
   * expression in the syntax of <code>java.util.regex.Pattern</code>.  The translation
   * assumes that the string to be matched against the regex uses surrogate pairs correctly.
   * If the string comes from XML content, a conforming XML parser will automatically
   * check this; if the string comes from elsewhere, it may be necessary to check
   * surrogate usage before matching.
   *
   * @param regexp a String containing a regular expression in the syntax of XML Schemas Part 2
   * @return TranslationInfo containing a String representing a regular expression in the syntax of java.util.regex.Pattern
   * @throws RegexSyntaxException if <code>regexp</code> is not a regular expression in the
   * syntax of XML Schemas Part 2
   * @see java.util.regex.Pattern
   * @see <a href="http://www.w3.org/TR/xmlschema-2/#regexs">XML Schema Part 2</a>
   */
  protected static List<SimpleCharClass> _translate(Translator tr)
    throws RegexSyntaxException {
    CharClass cc = tr.translateTop();
    return cc.toRanges();
  }

  private void advance() {
    if (pos < length) {
      switch ((curChar = regExp.charAt(pos++))) {
        case '\011': // tab (#x9)
        case '\012': // lf (#xA)
        case '\015': // cr (#xD)
        case '\040': // space (#x20)
          break;
      }
    }
    else {
      pos++;
      curChar = EOS;
      eos = true;
    }
  }

  private static class CharClassHolder {
    CharClass cc;
  }
  
  private CharClass translateTop() throws RegexSyntaxException {
    advance();
    CharClass cc = translateRegExp(new CharClassHolder());
    if (!eos)
      throw makeException("expected_eos");
    return cc;
  }

  /**
   * [1] regExp ::= branch ( '|' branch )*  
   */
  private CharClass translateRegExp(CharClassHolder cch) throws RegexSyntaxException {
    CharClass cc = translateBranch(cch);
    if (curChar != '|') {
      return cc;
    }
    final List<CharClass> listOfCC;
    listOfCC = new ArrayList<CharClass>();
    listOfCC.add(cc);
    do {
      advance();
      cc = translateBranch(cch);
      listOfCC.add(cc);
    } 
    while (curChar == '|');
    
    return new Union(listOfCC);
  }

  /**
   * [2] branch ::= piece*
   * [3] piece  ::= atom quantifier?  
   */
  private CharClass translateBranch(CharClassHolder cch) throws RegexSyntaxException {
    if (!translateAtom(cch)) {
      return cch.cc;
    }
    translateQuantifier();
    final List<CharClass> listOfCC;
    listOfCC = new ArrayList<CharClass>();
    listOfCC.add(cch.cc);
    while (translateAtom(cch)) {
      translateQuantifier();
      listOfCC.add(cch.cc);
    }
    return new Union(listOfCC);
  }

  private void translateQuantifier() throws RegexSyntaxException {
    switch (curChar) {
      case '*':
      case '?':
      case '+':
        advance();
        break;
      case '{':
        advance();
        translateQuantity();
        expect('}');
        advance();
        break;
      default:
        return;
    }
  }

  private void translateQuantity() throws RegexSyntaxException {
    String lower = parseQuantExact();
    int lowerValue = -1;
    try {
      lowerValue = Integer.parseInt(lower);
      //result.append(lower);
    }
    catch (NumberFormatException e) {
      // JDK 1.4 cannot handle ranges bigger than this
      //result.append(Integer.MAX_VALUE);
    }
    if (curChar == ',') {
      advance();
      if (curChar != '}') {
        String upper = parseQuantExact();
        try {
          int upperValue = Integer.parseInt(upper);
          //result.append(upper);
          if (lowerValue < 0 || upperValue < lowerValue)
            throw makeException("invalid_quantity_range");
        }
        catch (NumberFormatException e) {
          //result.append(Integer.MAX_VALUE);
          if (lowerValue < 0 && new BigDecimal(lower).compareTo(new BigDecimal(upper)) > 0)
            throw makeException("invalid_quantity_range");
        }
      }
    }
  }

  private String parseQuantExact() throws RegexSyntaxException {
    StringBuffer buf = new StringBuffer();
    do {
      if ("0123456789".indexOf(curChar) < 0)
        throw makeException("expected_digit");
      buf.append(curChar);
      advance();
    } while (curChar != ',' && curChar != '}');
    return buf.toString();
  }

  /**
   * [9]   atom ::= Char | charClass | ( '(' regExp ')' ) 
   * [10]  Char ::= [^.\?*+()|#x5B#x5D]
   * [11]  charClass     ::= charClassEsc | charClassExpr | WildcardEsc
   * [12]  charClassExpr ::= '[' charGroup ']'
   * [37a] WildcardEsc   ::= '.'  
   */
  private boolean translateAtom(CharClassHolder cch) throws RegexSyntaxException {
    cch.cc = null;
    switch (curChar) {
      case EOS:
        if (eos) {
          return false;
        }
        break;
      case '(': // i.e. '(' regExp ')'
        advance();
        cch.cc = translateRegExp(cch);
        expect(')');
        advance();
        return true;
      case '\\': // i.e. charClassEsc
        advance();
        cch.cc = parseCharClassEsc();
        return true;
      case '[': // charClassExpr ::= '[' charGroup ']'
        advance();
        cch.cc = parseCharClassExpr();
        return true;
      case '.': // i.e. WildcardEsc
        // TODO: implement
        cch.cc = new CharRange(0, NONBMP_MAX);
        break;
      case '$':
      case '^':
        cch.cc = new SingleChar(curChar);
        break;
      default:
        if (isRegExpMetaChar(curChar))
          return false;
        else
          cch.cc = new SingleChar(curChar);
        break;
    }
    advance();
    return true;
  }
  
  /**
   * [23] charClassEsc  ::= ( SingleCharEsc | MultiCharEsc | catEsc | complEsc )
   * 
   * [24] SingleCharEsc ::= '\' [nrt\|.?*+(){}#x2D#x5B#x5D#x5E]
   * [25] catEsc        ::= '\p{' charProp '}' 
   * [26] complEsc      ::= '\P{' charProp '}'  
   * [37] MultiCharEsc  ::= '\' [sSiIcCdDwW] 
   */
  private CharClass parseCharClassEsc() throws RegexSyntaxException {
    switch (curChar) {
    case 'n':
      advance();
      return new SingleChar('\n');
    case 'r':
      advance();
      return new SingleChar('\r');
    case 't':
      advance();
      return new SingleChar('\t');
    case 'i':
    case 'I':
    case 'c':
    case 'C':
      throw new RegexSyntaxException("\\" + curChar + " was used.");
    case 's':
      advance();
      return new Union(new SimpleCharClass[] {
          new SingleChar('\t'), new SingleChar('\n'), new SingleChar('\r'), new SingleChar(' ') });
    case 'S':
    case 'd':
    case 'D':
    case 'w':
    case 'W':
    case 'p':
    case 'P':
      throw new RegexSyntaxException("\\" + curChar + " was used.");
    case '-':
    case '^':
      break;
    default:
      if (isRegExpMetaChar(curChar)) {
        break;
      }
      throw makeException("bad_escape");
    }
    CharClass tem = new SingleChar(curChar);
    advance();
    return tem;
  }

  static protected boolean isAsciiAlnum(char c) {
    if ('a' <= c && c <= 'z')
      return true;
    if ('A' <= c && c <= 'Z')
      return true;
    if ('0' <= c && c <= '9')
      return true;
    return false;
  }

  protected void expect(char c) throws RegexSyntaxException {
    if (curChar != c)
      throw makeException("expected", new String(new char[]{c}));
  }

  /**
   * [12] charClassExpr ::= '[' charGroup ']'
   * [13] charGroup     ::= posCharGroup | negCharGroup | charClassSub 
   * 
   * [15] negCharGroup  ::= '^' posCharGroup
   *  
   * [14] posCharGroup  ::= ( charRange | charClassEsc )+
   * [16] charClassSub  ::= ( posCharGroup | negCharGroup ) '-' charClassExpr   
   */
  private CharClass parseCharClassExpr() throws RegexSyntaxException {
    boolean compl;
    if (curChar == '^') { // negCharGroup  ::= '^' posCharGroup
      advance();
      compl = true;
    }
    else
      compl = false;
    List<CharClass> members = new ArrayList<CharClass>();
    do { // posCharGroup  ::= ( charRange | charClassEsc )+
      final CharClass lower = parseCharClassEscOrXmlChar();
      if (curChar == '-') {
        advance();
        if (curChar == '[') {
          members.add(lower);
          break;
        }
        CharClass upper = parseCharClassEscOrXmlChar();
        if (lower.singleChar() < 0 || upper.singleChar() < 0)
          throw makeException("multi_range");
        if (lower.singleChar() > upper.singleChar())
          throw makeException("invalid_range");
        members.add(new CharRange(lower.singleChar(), upper.singleChar()));
        if (curChar == '-') {
          advance();
          expect('[');
          break;
        }
      }
      else
        members.add(lower);
    } while (curChar != ']');
    CharClass result;
    if (members.size() == 1)
      result = (CharClass)members.get(0);
    else
      result = new Union(members);
    if (compl)
      result = new Complement(result);
    if (curChar == '[') {
      advance();
      // charClassSub  ::= ( posCharGroup | negCharGroup ) '-' charClassExpr
      result = new Subtraction(result, parseCharClassExpr());
      expect(']');
    }
    advance();
    return result;
  }

  private CharClass parseCharClassEscOrXmlChar() throws RegexSyntaxException {
    switch (curChar) {
    case EOS:
      if (eos)
        expect(']');
      break;
    case '\\':
      advance();
      return parseCharClassEsc();
    case '[':
    case ']':
    case '-':
      throw makeException("should_quote", new String(new char[]{curChar}));
    }
    CharClass tem;
    if (Utf16.isSurrogate(curChar)) {
      if (!Utf16.isSurrogate1(curChar))
        throw makeException("invalid_surrogate");
      char c1 = curChar;
      advance();
      if (!Utf16.isSurrogate2(curChar))
        throw makeException("invalid_surrogate");
      tem = new SingleChar(Utf16.scalarValue(c1, curChar));
    }
    else
      tem = new SingleChar(curChar);
    advance();
    return tem;
  }

  protected RegexSyntaxException makeException(String key) {
    return new RegexSyntaxException(key, pos - 1);
  }

  protected RegexSyntaxException makeException(String key, String arg) {
    return new RegexSyntaxException(key + " \"" + arg + "\"", pos - 1);
  }

  static boolean isJavaMetaChar(int c) {
    switch (c) {
    case '\\':
    case '^':
    case '?':
    case '*':
    case '+':
    case '(':
    case ')':
    case '{':
    case '}':
    case '|':
    case '[':
    case ']':
    case '-':
    case '&':
    case '$':
    case '.':
      return true;
    }
    return false;
  }

  private static boolean isRegExpMetaChar(int c) {
    // [.\?*+{}()|#x5B#x5D]
    switch (c) {
      case '.':
      case '\\':
      case '?':
      case '*':
      case '+':
      case '(':
      case ')':
      case '{':
      case '}':
      case '|':
      case '[':
      case ']':
        return true;
    }
    return false;
  }

  static abstract class CharClass {

    abstract List<SimpleCharClass> toRanges();

    public int singleChar() {
      return -1;
    }

  }

  static abstract class SimpleCharClass extends CharClass implements Comparable {
    
    abstract int getMin();
    abstract int getMax();
    abstract int getCharacterCount();
    
    final List<SimpleCharClass> toRanges() {
      ArrayList<SimpleCharClass> arrayList = new ArrayList<SimpleCharClass>();
      arrayList.add(this);
      return arrayList;
    }
    
    public final int compareTo(Object obj) {
      SimpleCharClass theOther = (SimpleCharClass)obj;
      final int min1 = getMin();
      final int min2 = theOther.getMin();
      if (min1 < min2)
        return -1;
      else if (min1 != min2)
        return 1;
      else {
        final int max1 = getMax();
        final int max2 = theOther.getMax();
        if (max1 > max2)
          return -1;
        else if (max1 < max2)
          return 1;
        else
          return 0;
      }
    }
  }

  static class SingleChar extends SimpleCharClass {
    private final int c;
    SingleChar(int c) {
      super();
      this.c = c;
    }

    public int singleChar() {
      return c;
    }

    public int getMin() {
      return c;
    }
    
    public int getMax() {
      return c;
    }
    
    public int getCharacterCount() {
      return 1;
    }
  }

//  static class Empty extends CharClass {
//    static private final Empty instance = new Empty();
//    private Empty() {
//      super();
//    }
//
//    static Empty getInstance() {
//      return instance;
//    }
//
//    ArrayList<SimpleCharClass> outputChars() {
//      return CHARS_NONE;
//    }
//  }

  static class CharRange extends SimpleCharClass {
    private final int lower;
    private final int upper;

    CharRange(int lower, int upper) {
      super();
      this.lower = lower;
      this.upper = upper;
    }

    @Override
    int getMin() {
      return lower;
    }
    
    @Override
    int getMax() {
      return upper;
    }

    @Override
    int getCharacterCount() {
      return upper - lower + 1;
    }
  }

  private static SimpleCharClass createSimpleCharClass(int lower, int upper) {
    if (lower == upper) {
      return new SingleChar(lower);
    }
    else {
      assert lower < upper;
      return new CharRange(lower, upper);
    }
  }

  static class Subtraction extends CharClass {
    private ArrayList<SimpleCharClass> ranges; 

    Subtraction(CharClass cc1, CharClass cc2) {
      List<SimpleCharClass> listOfCC1 = cc1.toRanges();
      List<SimpleCharClass> listOfCC2 = cc2.toRanges();
      ranges = outputChars(listOfCC1, listOfCC2);
    }

    final ArrayList<SimpleCharClass> toRanges() {
      return ranges;
    }

    ArrayList<SimpleCharClass> outputChars(List<SimpleCharClass> includeList, List<SimpleCharClass> excludeList) {
      ArrayList<SimpleCharClass> newList;
      int exclen = excludeList.size();
      int inclen = includeList.size();
      newList = new ArrayList<SimpleCharClass>();
      if (inclen == 0) {
        return newList;
      }
      int lower, upper;
      int i, ind;
      ind = 0;
      SimpleCharClass included = includeList.get(ind++);
      lower = included.getMin();
      upper = included.getMax();
      for (i = 0; i < exclen && included != null; ) {
        SimpleCharClass excluded = excludeList.get(i);
        int min = excluded.getMin();
        int max = excluded.getMax();
        if (lower < min) {
          if (upper < min) { // no overlap
            newList.add(createSimpleCharClass(lower, upper));
            included = ind < inclen ? includeList.get(ind++) : null;
            if (included != null) {
              lower = included.getMin();
              upper = included.getMax();
            }
          }
          else { // there is overlap
            newList.add(createSimpleCharClass(lower, min - 1));
            if (upper <= max) {
              if (upper == max)
                ++i;
              included = ind < inclen ? includeList.get(ind++) : null;  
              if (included != null) {
                lower = included.getMin();
                upper = included.getMax();
              }
            }
            else { // max < upper
              ++i;
              lower = max + 1;
            }
          }
        }
        else if (min < lower){
          if (lower < max) {
            if (max < upper) {
              ++i;
              lower = max + 1;
            }
            else { // upper <= max
              if (upper == max)
                ++i;
              included = ind < inclen ? includeList.get(ind++) : null;  
              if (included != null) {
                lower = included.getMin();
                upper = included.getMax();
              }
            }
          }
          else if (max < lower) { // no overlap
            ++i;
          }
          else { // max == lower
            if (lower < upper) {
              lower = max + 1;
            }
            else {
              included = ind < inclen ? includeList.get(ind++) : null;  
              if (included != null) {
                lower = included.getMin();
                upper = included.getMax();
              }
            }
            ++i;
          }
        }
        else { // min == lower
          if (max < upper) {
            ++i;
            lower = max + 1;
          }
          else if (upper <= max) {
            if (upper == max)
              ++i;
            included = ind < inclen ? includeList.get(ind++) : null;  
            if (included != null) {
              lower = included.getMin();
              upper = included.getMax();
            }
          }
        }
      }
      if (included != null) {
        newList.add(createSimpleCharClass(lower, upper));
        while (ind < inclen) {
          included = includeList.get(ind++);
          newList.add(createSimpleCharClass(included.getMin(), included.getMax()));
        }
      }
      return newList;
    }
  }

  static class Union extends CharClass {
    
    private final ArrayList<SimpleCharClass> ranges;
    
    /**
     * The argument must be well-formed. 
     */
    Union(SimpleCharClass[] v) {
      ranges = new ArrayList<SimpleCharClass>();
      for (int i = 0; i < v.length; i++) {
        ranges.add(v[i]);
      }
    }

    Union(List<CharClass> ccs) {
      ArrayList<SimpleCharClass> ranges = new ArrayList<SimpleCharClass>(); 
      for (int i = 0; i < ccs.size(); i++) {
        CharClass cc = ccs.get(i);
        List<SimpleCharClass> sccs = cc.toRanges();
        for (int j = 0; j < sccs.size(); j++) {
          ranges.add(sccs.get(j));
        }
      }
      this.ranges = ranges;
    }
    
    final List<SimpleCharClass> toRanges() {
      TreeSet<SimpleCharClass> sorted = new TreeSet<SimpleCharClass>();
      for (int i = 0; i < ranges.size(); i++) {
        sorted.add(ranges.get(i));
      }
      ArrayList<SimpleCharClass> ranges;
      ranges = new ArrayList<SimpleCharClass>();
      SimpleCharClass cc = null;
      Iterator<SimpleCharClass> iterator = sorted.iterator();
      while (iterator.hasNext()) {
        SimpleCharClass nextcc = iterator.next();
        if (cc == null) {
          cc = nextcc;
          continue;
        }
        int min1 = cc.getMin();
        int min2 = nextcc.getMin();
        if (min1 == min2) {
          assert cc.getMax() >= nextcc.getMax();
          continue;
        }
        else { // min1 < min2
          assert min1 < min2;
          int max1 = cc.getMax();
          if (max1 < min2) { // no overlap
            ranges.add(cc);
            cc = nextcc;
            continue;
          }
          int max2 = nextcc.getMax();
          cc = createSimpleCharClass(min1, max1 < max2 ? max2 : max1);
        }
      }
      if (cc != null)
        ranges.add(cc);
      return ranges;
    }
    
  }

  static class Complement extends CharClass {
    private final ArrayList<SimpleCharClass> ranges;
    Complement(CharClass cc) {
      ranges = outputChars(cc);
    }

    final ArrayList<SimpleCharClass> toRanges() {
      return ranges;
    }

    private ArrayList<SimpleCharClass> outputChars(CharClass cc) {
      List<SimpleCharClass> baseList = cc.toRanges();
      int lower, upper;
      int i, len;
      SimpleCharClass range; 
      ArrayList<SimpleCharClass> newList = new ArrayList<SimpleCharClass>();
      for (i = 0, len = baseList.size(), lower = 0; i < len; i++) {
        SimpleCharClass excluded = baseList.get(i);
        int min = excluded.getMin();
        if (lower != min) {
          assert lower < min;
          upper = min - 1;
          range = createSimpleCharClass(lower, upper);
          newList.add(range);
        }
        lower = excluded.getMax() + 1;
      }
      if (lower <= NONBMP_MAX) {
        if (lower == NONBMP_MAX) {
          range = new SingleChar(lower);
        }
        else {
          assert lower < NONBMP_MAX;
          range = new CharRange(lower, NONBMP_MAX);
        }
        newList.add(range);
      }
      return newList;
    }
  }
  
}
