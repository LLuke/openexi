package com.thaiopensource.exi.xsd.regex.jdk1_4;

import java.util.List;

import com.thaiopensource.exi.xsd.regex.RegexSyntaxException;

/**
 */
public class Regexi {

  /**
   * Computes and returns the restricted character set (if any) for the
   * specified string.
   * @param str
   * @return restricted character set if any, otherwise null
   * @throws RegexSyntaxException
   */
  public static int[] compute(String str) throws RegexSyntaxException {
    List<Translator.SimpleCharClass> list = Translator.translate(str);
    int count = 0;
    int i, len;
    for (i = 0, len = list.size(); i < len; i++) {
      Translator.SimpleCharClass cc = list.get(i);
      count += cc.getCharacterCount();
      if (count >= 256)
        break;
    }
    if (i < len) {
      return null;
    }
    int[] chars = new int[count];
    int pos;
    for (i = 0, pos = 0; i < len; i++) {
      Translator.SimpleCharClass cc = list.get(i);
      int min = cc.getMin();
      int max = cc.getMax();
      if (max > 0xFFFF)
        break;
      for (int j = min; j <= max; j++, pos++) {
        chars[pos] = j;
      }
    }
    return i == len ? chars : null;
  }
  
}
